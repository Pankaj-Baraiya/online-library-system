import React from 'react';
import { Link } from 'react-router-dom';
import './NavigationBar.css'; // We'll create this CSS file later

const NavigationBar = () => {
  return (
    <nav className="navbar">
      <Link to="/" className="nav-link">Home</Link>
      <Link to="/browse-books" className="nav-link">Browse Books</Link>
      <Link to="/add-book" className="nav-link">Add Book</Link>
    </nav>
  );
};

export default NavigationBar;