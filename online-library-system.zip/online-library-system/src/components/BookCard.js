import React from 'react';
import { Link } from 'react-router-dom';
import './BookCard.css'; // We'll create this CSS file later

const BookCard = ({ book }) => {
  return (
    <div className="book-card">
      <h3>{book.title}</h3>
      <p>by {book.author}</p>
      <p>Category: {book.category}</p>
      <p>Rating: {book.rating} ⭐</p>
      <Link to={`/books/details/${book.id}`} className="view-details-link">
        View Details
      </Link>
    </div>
  );
};

export default BookCard;