import React from 'react';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import BookCard from '../components/BookCard';
import './HomePage.css'; // We'll create this CSS file later

const HomePage = () => {
  const books = useSelector((state) => state.books.books);

  // Get unique categories
  const categories = [...new Set(books.map((book) => book.category))];

  // Simple logic for popular books: top 3 by rating
  const popularBooks = [...books].sort((a, b) => b.rating - a.rating).slice(0, 3);

  return (
    <div className="home-page">
      <h1>Welcome to the Online Library System!</h1>
      <p>Explore a vast collection of books from various genres.</p>

      <section className="book-categories">
        <h2>Book Categories</h2>
        <div className="categories-list">
          {categories.map((category) => (
            <Link key={category} to={`/browse-books?category=${category}`} className="category-link">
              {category}
            </Link>
          ))}
        </div>
      </section>

      <section className="popular-books">
        <h2>Popular Books</h2>
        <div className="popular-books-list">
          {popularBooks.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
        <Link to="/browse-books" className="view-more-books">View More Books</Link>
      </section>
    </div>
  );
};

export default HomePage;