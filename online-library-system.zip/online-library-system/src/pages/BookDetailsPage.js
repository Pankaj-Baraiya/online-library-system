import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import './BookDetailsPage.css'; // We'll create this CSS file later

const BookDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const books = useSelector((state) => state.books.books);
  const book = books.find((b) => b.id === id);

  if (!book) {
    return <div className="book-details-page"><h2>Book Not Found</h2></div>;
  }

  return (
    <div className="book-details-page">
      <h1>{book.title}</h1>
      <p className="author">by {book.author}</p>
      <p className="category">Category: {book.category}</p>
      <p className="rating">Rating: {book.rating} ⭐</p>
      <div className="description-box">
        <h3>Description:</h3>
        <p>{book.description}</p>
      </div>
      <button onClick={() => navigate('/browse-books')} className="back-button">
        Back to Browse
      </button>
    </div>
  );
};

export default BookDetailsPage;