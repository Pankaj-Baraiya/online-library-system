import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { addBook } from '../actions/bookActions';
import { v4 as uuidv4 } from 'uuid'; // For unique IDs
import './AddBookPage.css'; // We'll create this CSS file later

const AddBookPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const books = useSelector((state) => state.books.books); // To get existing categories

  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [rating, setRating] = useState('');
  const [errors, setErrors] = useState({});

  const uniqueCategories = [...new Set(books.map((book) => book.category))];

  const validateForm = () => {
    const newErrors = {};
    if (!title.trim()) newErrors.title = 'Title is required';
    if (!author.trim()) newErrors.author = 'Author is required';
    if (!description.trim()) newErrors.description = 'Description is required';
    if (!category.trim()) newErrors.category = 'Category is required';
    if (!rating || isNaN(rating) || rating < 1 || rating > 5) {
      newErrors.rating = 'Rating must be a number between 1 and 5';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      const newBook = {
        id: uuidv4(),
        title,
        author,
        description,
        category,
        rating: parseFloat(rating),
      };
      dispatch(addBook(newBook));
      navigate('/browse-books'); // Redirect after submission
    }
  };

  return (
    <div className="add-book-page">
      <h1>Add New Book</h1>
      <form onSubmit={handleSubmit} className="add-book-form">
        <div className="form-group">
          <label htmlFor="title">Title:</label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          {errors.title && <span className="error">{errors.title}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="author">Author:</label>
          <input
            type="text"
            id="author"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
          />
          {errors.author && <span className="error">{errors.author}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="description">Description:</label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows="5"
          ></textarea>
          {errors.description && <span className="error">{errors.description}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="category">Category:</label>
          <input
            list="categories"
            id="category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            placeholder="Select or type a category"
          />
          <datalist id="categories">
            {uniqueCategories.map((cat) => (
              <option key={cat} value={cat} />
            ))}
          </datalist>
          {errors.category && <span className="error">{errors.category}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="rating">Rating (1-5):</label>
          <input
            type="number"
            id="rating"
            value={rating}
            onChange={(e) => setRating(e.target.value)}
            min="1"
            max="5"
            step="0.1"
          />
          {errors.rating && <span className="error">{errors.rating}</span>}
        </div>

        <button type="submit" className="submit-button">Add Book</button>
      </form>
    </div>
  );
};

export default AddBookPage;