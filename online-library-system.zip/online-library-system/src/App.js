import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './store'; // Import your Redux store

import NavigationBar from './components/NavigationBar';
import HomePage from './pages/HomePage';
import BrowseBooksPage from './pages/BrowseBooksPage';
import BookDetailsPage from './pages/BookDetailsPage';
import AddBookPage from './pages/AddBookPage';
import NotFoundPage from './pages/NotFoundPage';

import './App.css'; // For general app styling

function App() {
  return (
    <Provider store={store}> {/* Wrap your app with Provider */}
      <Router>
        <NavigationBar /> {/* Navigation bar visible on all pages */}
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/browse-books" element={<BrowseBooksPage />} />
            {/* Dynamic route for filtering by category */}
            <Route path="/browse-books/:category" element={<BrowseBooksPage />} />
            {/* Dynamic route for book details */}
            <Route path="/books/details/:id" element={<BookDetailsPage />} />
            <Route path="/add-book" element={<AddBookPage />} />
            <Route path="*" element={<NotFoundPage />} /> {/* 404 route */}
          </Routes>
        </main>
      </Router>
    </Provider>
  );
}

export default App;