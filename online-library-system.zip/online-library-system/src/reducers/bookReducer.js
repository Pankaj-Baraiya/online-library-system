const initialState = {
  books: [
    {
      id: '1',
      title: 'The Great Gatsby',
      author: 'F. Scott Fitzgerald',
      description: 'A novel about the American Dream.',
      category: 'Fiction',
      rating: 4.5,
    },
    {
      id: '2',
      title: 'Sapiens: A Brief History of Humankind',
      author: 'Yuval Noah Harari',
      description: 'A brief history of our species.',
      category: 'Non-Fiction',
      rating: 4.8,
    },
    {
      id: '3',
      title: 'Dune',
      author: 'Frank Herbert',
      description: 'A science fiction masterpiece.',
      category: 'Sci-Fi',
      rating: 4.7,
    },
    {
      id: '4',
      title: 'To Kill a Mockingbird',
      author: 'Harper Lee',
      description: 'A novel about racial injustice in the American South.',
      category: 'Fiction',
      rating: 4.6,
    },
    {
      id: '5',
      title: 'Cosmos',
      author: 'Carl Sagan',
      description: 'A journey through space and time.',
      category: 'Sci-Fi',
      rating: 4.9,
    },
  ],
};

const bookReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'ADD_BOOK':
      return {
        ...state,
        books: [...state.books, action.payload],
      };
    default:
      return state;
  }
};

export default bookReducer;